# 🐆 pantershop.co — Analytics Dashboard

Live Shopify analytics dashboard deployovan na Vercel.

---

## 📁 Struktura projekta

```
shopify-dashboard/
├── api/
│   └── shopify.js       ← Vercel serverless proxy (skriva API token)
├── public/
│   └── index.html       ← Dashboard UI
├── vercel.json          ← Vercel konfiguracija
├── .env.example         ← Template za env varijable
└── .gitignore           ← Isključuje .env iz Git-a
```

---

## 🚀 Deploy korak po korak

### Korak 1 — Postavi GitHub repo

1. Idi na [github.com](https://github.com) → klikni **"New repository"**
2. Ime: `shopify-dashboard` → **Create repository**
3. Otpakuj zip koji si dobio i upload-uj fajlove:
   - Klikni **"uploading an existing file"**
   - Prevuci sve fajlove (`api/`, `public/`, `vercel.json`, `.gitignore`, `.env.example`)
   - Klikni **"Commit changes"**

### Korak 2 — Poveži Vercel sa GitHub

1. Idi na [vercel.com](https://vercel.com) → **"Add New Project"**
2. Klikni **"Import"** pored `shopify-dashboard` repoa
3. Framework Preset: ostavi **"Other"**
4. Klikni **"Deploy"** — Vercel će automatski detektovati `vercel.json`

### Korak 3 — Postavi Environment Variables na Vercel

1. Nakon deploymenta idi na projekat → **Settings → Environment Variables**
2. Dodaj ove 3 varijable:

| Name | Value |
|------|-------|
| `SHOPIFY_STORE` | `pantershop.co` |
| `SHOPIFY_TOKEN` | `shpat_tvoj_token_ovde` |
| `DASHBOARD_PASSWORD` | `izmisli_jaku_lozinku` |

3. Klikni **Save** → idi na **Deployments** → klikni **"Redeploy"**

### Korak 4 — Pristup dashboardu

- Vercel ti daje URL: `https://shopify-dashboard-xxx.vercel.app`
- Otvori URL → unesi svoju lozinku → enjoy! 🎉

---

## 🔐 Bezbednost

- API token se **nikad ne šalje browseru** — ostaje na Vercel serveru
- Dashboard je zaštićen lozinkom
- `.env` fajl je u `.gitignore` — nikad neće ići na GitHub

---

## 📊 Šta dashboard prikazuje

- 💚 **Ukupna zarada** u odabranom periodu
- 🔵 **Broj porudžbina** (aktivne vs otkazane)
- 🟠 **Prosečna vrednost** porudžbine
- 🔴 **Otkazane** — broj, izgubljen prihod, stopa %
- 📊 **Grafikon zarade** po danima
- 📋 **Lista porudžbina** sa statusima na srpskom
- 🥇 **Top proizvodi** po prihodu

Period: 7 / 14 / 30 / 90 dana | Auto-refresh: svake 2 minute

---

## 🛠 Ažuriranje

Svaki put kad pushuješ promenu na GitHub, Vercel automatski redeploy-uje.
