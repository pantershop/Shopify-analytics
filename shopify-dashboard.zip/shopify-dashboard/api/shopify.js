// api/shopify.js — Vercel Serverless Function
// Ovo je proxy koji skriva tvoj Shopify token od browsera

export default async function handler(req, res) {
  // ─── CORS Headers ───────────────────────────────────────
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // ─── Lozinka zaštita ────────────────────────────────────
  const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD;
  const authHeader = req.headers['authorization'];

  if (!authHeader || authHeader !== `Bearer ${DASHBOARD_PASSWORD}`) {
    return res.status(401).json({ error: 'Neispravna lozinka.' });
  }

  // ─── Shopify kredencijali iz env varijabli ──────────────
  const SHOPIFY_STORE = process.env.SHOPIFY_STORE;       // pantershop.co
  const SHOPIFY_TOKEN = process.env.SHOPIFY_TOKEN;       // shpat_xxx

  if (!SHOPIFY_STORE || !SHOPIFY_TOKEN) {
    return res.status(500).json({ error: 'Shopify env varijable nisu postavljene.' });
  }

  // ─── Koji endpoint da pozovemo? ─────────────────────────
  const { endpoint } = req.query;

  const allowedEndpoints = [
    'orders',
    'shop',
    'products/count',
  ];

  if (!endpoint || !allowedEndpoints.some(e => endpoint.startsWith(e))) {
    return res.status(400).json({ error: `Endpoint nije dozvoljen: ${endpoint}` });
  }

  // ─── Prosledi query parametre ka Shopify ────────────────
  const queryParams = { ...req.query };
  delete queryParams.endpoint; // ukloni naš interni param

  const queryString = new URLSearchParams(queryParams).toString();
  const shopifyUrl = `https://${SHOPIFY_STORE}/admin/api/2024-01/${endpoint}.json${queryString ? '?' + queryString : ''}`;

  try {
    const shopifyRes = await fetch(shopifyUrl, {
      headers: {
        'X-Shopify-Access-Token': SHOPIFY_TOKEN,
        'Content-Type': 'application/json',
      },
    });

    // Prosleđujemo Link header za paginaciju
    const linkHeader = shopifyRes.headers.get('Link');
    if (linkHeader) res.setHeader('X-Link', linkHeader);

    const data = await shopifyRes.json();

    if (!shopifyRes.ok) {
      return res.status(shopifyRes.status).json({ error: data });
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error('Shopify fetch error:', err);
    return res.status(500).json({ error: 'Greška pri komunikaciji sa Shopify API-jem.' });
  }
}
